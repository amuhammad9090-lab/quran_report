import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:media_store_plus/media_store_plus.dart';
import 'package:provider/provider.dart';

import 'app.dart';
import 'data/services/app_prefs_service.dart';
import 'data/services/download_notification_service.dart';
import 'data/services/firebase_bootstrap_status.dart';
import 'data/services/parent_reply_notification_service.dart';
import 'data/services/quran_engine_service.dart';
import 'data/services/storage_service.dart';
import 'firebase_options.dart';
import 'presentation/screens/notifications/notifications_screen.dart';
import 'providers/auth_provider.dart';
import 'providers/folders_provider.dart';
import 'providers/parent_notes_provider.dart';
import 'providers/records_provider.dart';
import 'providers/students_provider.dart';
import 'providers/theme_provider.dart';

// <-- BERUBAH (migrasi auth: Anonymous -> Google Sign-In).
void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  try {
    try {
      await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
    } on FirebaseException catch (e) {
      if (e.code != 'duplicate-app') rethrow;
      debugPrint('Firebase app "[DEFAULT]" sudah ada duluan (native/hot-restart) -- pakai yang itu.');
    }

    // <-- BERUBAH: [FirebaseBootstrapStatus.ready] sekarang murni berarti
    // "Firebase Core berhasil di-initialize" (SDK siap dipakai)
    FirebaseBootstrapStatus.markReady();
    if (kIsWeb) {
      FirebaseFirestore.instance.settings = const Settings(
        persistenceEnabled: false,
        webExperimentalAutoDetectLongPolling: true,
      );
    }
  } catch (e, st) {
    debugPrint('Firebase.initializeApp() GAGAL: $e');
    debugPrint('$st');
    FirebaseBootstrapStatus.markFailed(e);
  }

  if (!kIsWeb) {
    await MediaStore.ensureInitialized();
    MediaStore.appFolder = 'Quran Report';
  }

  await initializeDateFormatting('id_ID', null);
  await StorageService.instance.init();
  await AppPrefsService.instance.init();
  await QuranEngineService.instance.load();
  await DownloadNotificationService.instance.init();
  // Navigasi tap notifikasi: service data tidak mengenal UI, jadi rutenya dipasang di sini.
  ParentReplyNotificationService.instance.onOpenNotifications = () {
    final nav = QuranReportApp.navigatorKey.currentState;
    if (nav == null) return false;
    nav.push(MaterialPageRoute(builder: (_) => const NotificationsScreen()));
    return true;
  };
  await ParentReplyNotificationService.instance.init();

  final themeProvider = ThemeProvider();
  await themeProvider.load();

  final authProvider = AuthProvider();
  await authProvider.restoreSession();

  final recordsProvider = RecordsProvider();
  await recordsProvider.load();

  recordsProvider.updateScope(authProvider.scope);
  StorageService.instance.updateScope(authProvider.scope);
  AppPrefsService.instance.updateScope(authProvider.scope);

  final foldersProvider = FoldersProvider();
  await foldersProvider.load();

  final studentsProvider = StudentsProvider();
  await studentsProvider.load();

  final parentNotesProvider = ParentNotesProvider();
  parentNotesProvider.updateScope(authProvider.scope);
  parentNotesProvider.start();

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider.value(value: themeProvider),
        ChangeNotifierProvider.value(value: authProvider),
        ChangeNotifierProvider.value(value: recordsProvider),
        ChangeNotifierProvider.value(value: foldersProvider),
        ChangeNotifierProvider.value(value: studentsProvider),
        ChangeNotifierProvider.value(value: parentNotesProvider),
      ],
      child: const QuranReportApp(),
    ),
  );
}