import '../../core/utils/text_utils.dart';
import 'kelas_halaqoh.dart';

/// Role akses user. Admin = akses global, Guru Pembimbing = hanya data
/// assignment (kelas+halaqoh) miliknya sendiri.
enum UserRole {
  admin,
  guruPembimbing,
  /// Pengawas (mis. kepala sekolah/wakakur): LIHAT semua data seperti admin, tapi READ-ONLY --
  /// tidak bisa menambah/mengubah/menghapus apa pun (dijaga di UI, provider, DAN Firestore Rules).
  pengawas;

  String get label => switch (this) {
        UserRole.admin => 'Admin',
        UserRole.guruPembimbing => 'Guru Pembimbing',
        UserRole.pengawas => 'Pengawas',
      };

  static UserRole fromName(String name) {
    final n = name.trim().toLowerCase();
    if (n == 'admin') return UserRole.admin;
    if (n == 'pengawas' || n == 'viewer') return UserRole.pengawas;
    // 'guru_pembimbing' (nama resmi terbaru), serta nama lama
    // 'musyrif'/'guru_alquran' (dari data sekolah versi sebelumnya)
    // dianggap sama. Nilai lain yang tidak dikenal juga fallback ke
    // guruPembimbing (bukan admin) supaya defaultnya selalu yang PALING
    // TERBATAS, bukan yang paling luas aksesnya.
    return UserRole.guruPembimbing;
  }
}

/// Akun user (guru pembimbing/admin) — dipakai oleh [AuthRepository].
///
/// `passwordHash` TIDAK PERNAH menyimpan plaintext (lihat
/// `AuthHashService`). Field ini murni model data, tidak tahu-menahu soal
/// mekanisme hashing/verifikasi.
class UserAccount {
  final String id;
  final String username;
  final String displayName;
  final String passwordHash;
  final UserRole role;

  /// Assignment kelas+halaqoh yang diampu, sebagai PASANGAN (lihat
  /// dokumentasi [KelasHalaqoh] — kenapa ini bukan dua list terpisah).
  /// Untuk admin biasanya kosong (akses global, tidak dibatasi list ini).
  final List<KelasHalaqoh> assignments;

  final String schoolId;

  /// Path foto profil LOKAL (belum ada backend upload). Null = pakai
  /// fallback avatar inisial nama.
  final String? photoPath;

  /// <-- BARU (migrasi auth: Anonymous -> Google Sign-In). Email Google
  /// yang di-WHITELIST admin buat akun ini (lihat KelolaGuruScreen &
  /// ApiAuthRepository.updateGoogleEmail) -- INI yang jadi identifier
  /// utama buat memetakan Firebase User (hasil Google Sign-In) ke
  /// [UserAccount] yang benar (lihat AuthProvider.signInWithGoogle &
  /// ApiAuthRepository.findByGoogleEmail), BUKAN [username]/[passwordHash]
  /// lagi (dua field itu TETAP ada, TIDAK dihapus, tapi sudah tidak
  /// dipakai jalur login manapun sejak migrasi ini -- lihat laporan
  /// migrasi auth).
  ///
  /// Selalu disimpan huruf kecil semua & sudah di-trim (lihat
  /// [ApiAuthRepository.updateGoogleEmail]) supaya perbandingan dengan
  /// email dari Firebase User (yang juga di-lowercase dulu sebelum
  /// dibandingkan) konsisten. Null/kosong = akun ini BELUM di-mapping
  /// admin ke akun Google manapun -- guru itu TIDAK BISA login sampai
  /// admin mengisi field ini (lihat BAGIAN 5/6 spesifikasi migrasi: akun
  /// Google TIDAK otomatis dapat akses hanya karena berhasil login).
  final String? googleEmail;

  const UserAccount({
    required this.id,
    required this.username,
    required this.displayName,
    required this.passwordHash,
    required this.role,
    this.assignments = const [],
    required this.schoolId,
    this.photoPath,
    this.googleEmail,
  });

  bool get isAdmin => role == UserRole.admin;
  bool get isPengawas => role == UserRole.pengawas;

  /// Kelas unik yang diampu (union dari [assignments]) — cuma buat
  /// keperluan TAMPILAN (mis. chip ringkasan di Profile). JANGAN dipakai
  /// buat keputusan akses — pakai [assignments] langsung / AccessScope.
  List<String> get distinctKelas => assignments.map((a) => a.kelas).toSet().toList();

  /// Halaqoh unik yang diampu — sama catatannya seperti [distinctKelas].
  List<String> get distinctHalaqoh => assignments.map((a) => a.halaqoh).toSet().toList();

  UserAccount copyWith({
    String? displayName,
    String? passwordHash,
    UserRole? role,
    List<KelasHalaqoh>? assignments,
    String? photoPath,
    bool clearPhoto = false,
    String? googleEmail,
    bool clearGoogleEmail = false,
  }) {
    return UserAccount(
      id: id,
      username: username,
      displayName: displayName ?? this.displayName,
      passwordHash: passwordHash ?? this.passwordHash,
      role: role ?? this.role,
      assignments: assignments ?? this.assignments,
      schoolId: schoolId,
      photoPath: clearPhoto ? null : (photoPath ?? this.photoPath),
      googleEmail: clearGoogleEmail ? null : (googleEmail ?? this.googleEmail),
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'username': username,
        'displayName': displayName,
        'passwordHash': passwordHash,
        'role': role.name,
        'assignments': assignments.map((a) => a.toJson()).toList(),
        'schoolId': schoolId,
        'photoPath': photoPath,
        'googleEmail': googleEmail, // <-- BARU
      };

  factory UserAccount.fromJson(Map<String, dynamic> json) {
    List<KelasHalaqoh> parsedAssignments;
    if (json['assignments'] is List) {
      // Bentuk baru (benar): list pasangan {kelas, halaqoh}.
      parsedAssignments = (json['assignments'] as List)
          .map((e) => KelasHalaqoh.fromJson(Map<String, dynamic>.from(e as Map)))
          .toList();
    } else {
      // Fallback data lama (dua list terpisah, SALAH secara semantik —
      // lihat dokumentasi KelasHalaqoh) — di-zip apa adanya berdasarkan
      // index biar tidak crash, tapi ini cuma best-effort migration,
      // bukan jaminan hasilnya benar kalau data lama itu sendiri sudah
      // ambigu.
      final kelasList = (json['kelas'] as List?)?.map((e) => e.toString()).toList() ?? const [];
      final halaqohList = (json['halaqoh'] as List?)?.map((e) => e.toString()).toList() ?? const [];
      final len = kelasList.length < halaqohList.length ? kelasList.length : halaqohList.length;
      parsedAssignments = [
        for (var i = 0; i < len; i++)
          KelasHalaqoh(kelas: kelasList[i], halaqoh: normalizeHalaqoh(halaqohList[i])),
      ];
    }

    return UserAccount(
      id: json['id'] as String,
      username: json['username'] as String,
      displayName: json['displayName'] as String,
      passwordHash: json['passwordHash'] as String,
      role: UserRole.fromName(json['role'] as String? ?? 'guru_pembimbing'),
      assignments: parsedAssignments,
      // schoolId opsional di data lama — default ke sekolah pertama supaya
      // tidak crash kalau field belum ada (backward compatible).
      schoolId: json['schoolId'] as String? ?? 'smpit_al_madinah_tanjungpinang',
      photoPath: json['photoPath'] as String?,
      // <-- BARU: null (atau field belum ada sama sekali) di data lama
      // berarti "belum pernah di-mapping admin" -- itu memang perilaku
      // yang diinginkan, BUKAN bug (lihat dokumentasi field ini). String
      // kosong dianggap sama dengan null, biar tidak ada whitelist entry
      // yang keliru "cocok" dengan email kosong.
      googleEmail: switch ((json['googleEmail'] as String?)?.trim().toLowerCase()) {
        null || '' => null,
        final email => email,
      },
    );
  }
}
